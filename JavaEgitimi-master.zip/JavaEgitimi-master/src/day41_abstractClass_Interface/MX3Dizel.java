package day41_abstractClass_Interface;

public abstract class MX3Dizel extends LX3 {



    /*
       Bir abstract class
       concrete bir class'i parent edinebilir
     */
}
