package day31_timeFormatter_varargs;

public class C07_StringBuilder {
    public static void main(String[] args) {

        StringBuilder sb1 = new StringBuilder(); //bos bir StringBuilder olur
        StringBuilder sb2 = new StringBuilder("animal");//belli degeri olan StringBuilder olusturur
        StringBuilder sb3 = new StringBuilder(5); //ilk uzunlugu tahmin eden StringBuilder olusturur

        System.out.println(sb1); //kod calisir ama cıkti vermez
        System.out.println(sb2);//animal
        System.out.println(sb3);//kod calisir ama cıkti vermez


















    }
}
