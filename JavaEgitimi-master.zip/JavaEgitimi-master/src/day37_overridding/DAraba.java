package day37_overridding;

public class DAraba {

   private void yakit(){
        System.out.println("Tum arabalar benzin kullanir");
        /*
        parent classdan override edilmesini istemediginiz methodlari
        private static ve final yapabilirsiniz
         */
    }

    void marka(){
        System.out.println("Tum arabalarin markasi vardir");
    }

    void motor(){
        System.out.println("Tum arabalarin motoru vardir");
    }





}
