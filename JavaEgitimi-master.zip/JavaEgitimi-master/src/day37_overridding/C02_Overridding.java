package day37_overridding;

public class C02_Overridding {
    public static void main(String[] args) {

        /*
        Farklı classlarda ayni isim ve signature da
        methodlar olusturabiliriz
        cunku her bir class kendi icinde calisir
         */


    }


    void ekleme(){

    }
    void ekleme(int sayi){

    }

    void ekleme(String str){

    }












}
