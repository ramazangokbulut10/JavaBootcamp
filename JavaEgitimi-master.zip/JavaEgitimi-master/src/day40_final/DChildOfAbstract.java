package day40_final;

public class DChildOfAbstract extends CAbstract {

    @Override
    void carpma() {
        /*
        Abstract classlar child claslarin
        sahip olmaları gereken
        mevburi ozellikleri belirlerler
        (Gunluk hayatımızdaki standartlar gibi)
        Abstract bir classi parent edinen tum childler
        parent abstract classdaki
        tum abstract methodları override etmek zorundadırlar
         */
    }

    @Override
    void bolme() {

    }
}
