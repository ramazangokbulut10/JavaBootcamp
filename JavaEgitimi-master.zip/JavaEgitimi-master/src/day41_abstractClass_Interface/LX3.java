package day41_abstractClass_Interface;

public class LX3 extends KBmw{


     /*
      X3 class'i abstract silsileden sonra gelen
      ilk concrete class oldugundan
      Tum abstract parent'lardaki, tum abstract method'lari
      override etmek ZORUNDA KALDI
     */





    @Override
    protected void yakit() {

    }

    @Override
    protected void kaporta() {

    }

    @Override
    protected void motor() {

    }

    @Override
    public void amblem() {

    }

    @Override
    public void guvenlik() {

    }
}
