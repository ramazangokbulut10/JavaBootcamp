package day41_abstractClass_Interface;

public class GCorolla extends EToyota {
    @Override
    protected void yakit() {

    }

    @Override
    protected void kaporta() {

    }

    /*
    Corolla classının iki tane prenti var
    corolla parentlerinin ikisinin de standartlarına(abstract method)
    uymak zorundadır

    Concrete class parenti olan tum abstract classlarda
    abstract olan methodları implemen etmek zorundadır
    ancak paarent silsilesinde override edilerek concrete yapılan methodları
    override etmek zorunda degildir

     */
}
