package day41_abstractClass_Interface;

public abstract class KBmw extends DAraba{

    /*
araba classindaki bodysi olmayan methodlar ne ise yarıyor
ya kural koy ya kurala uy diyor.
 */


     /*
      BMW abstract bir class'in
      abstract bir child'i oldugu icin
      Parent class'daki abstract method'lari implement etmek ZORUNDA KALMADI
     */





    public abstract void amblem();

    public abstract void guvenlik();



}
