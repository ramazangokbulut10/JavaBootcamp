package day37_overridding;

public class C01_Overloading {
    public static void main(String[] args) {
        /*
        bir classda aynı isimde ve aynı signature a sahip iki method olmaz
        Aynı classda aynı isimde birden fazla method olusturmak istersek
        mutlaka sagnature i degistiremeyiz

        Farklı classlarda aynı isim ve signature a sahip iki method olabilir mi?

         */


    }

    void ekleme(){

    }
    void ekleme(int sayi){

    }

    void ekleme(String str){

    }

    void ekleme(String str, int sayi){

    }

    void ekleme(int sayi, String str){

    }



}
