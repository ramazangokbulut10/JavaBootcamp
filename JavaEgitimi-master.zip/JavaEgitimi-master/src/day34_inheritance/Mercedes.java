package day34_inheritance;

public class Mercedes {
    protected String isim="Mercedes";
    protected String made="Germany";
    protected String motorYeri="onde";
}
