package day35_inhertancedaConstructorKullanimi;

public class DPersonel {

    DPersonel(){
        System.out.println("Personel Parametresiz cons");
    }
    DPersonel(String isim){
        System.out.println("Personel Parametreli cons");
    }


}
