package day34_inheritance;

public class S_Model extends Mercedes{

    protected int silindir=8;
    protected String sekment="Luks";

    public static void main(String[] args) {
        S_Model arb1=new S_Model();
        arb1.isim="Mercedes_S";

    }

}
