package day41_abstractClass_Interface;

public class FMercedes extends DAraba{
    @Override
    protected void yakit() {
        /*
        abstarct bir parentin concrente child class inherid ederse
        parent abstract classdaki tum abstract methodları
        override etmek zorundadır

        abstarct bir class abstract baska bir classı parent edinirse
        parent classdaki tum abstarct methodları override etmek
        zorunda degildir.


         */
    }

    @Override
    protected void kaporta() {

    }

    @Override
    protected void motor() {

    }
}
