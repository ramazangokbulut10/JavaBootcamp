package day37_overridding;

public class GCokluClass {
}

class ikinciClass{

    /*
    IntelliJ'de actıgımız bir class icinde
    sadece bir public class bulunabilir

    class sınırları disinda PUBLIC OLMAYAN baska classlarda olusturabiliriz
    ancak projede yazdigimiz class ismini public yapmazsak,
    proje ile class arasinda sorun olacagindan CTE olur.
     */

}

class ucuncuClass{

}
