package day14_methodCreation;

public class C06_MethodCreation {
    public static void main(String[] args) {

        System.out.println(C05_MethodCreationReturn.sehirAl()); //burada bit önceki methodu çagırdık kod yazmaya gerek kalmadı
    }
}
